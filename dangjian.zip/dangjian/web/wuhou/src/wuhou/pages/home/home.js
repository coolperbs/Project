define( 'wuhou/pages/home/home', function( require, exports, module ) {
    require( 'wuhou/pages/home/home.css' );
    require( 'wuhou/pages/home/home.tpl' );
    var handle, CFG, _fn, kDom, DOM_EVENT, userServices, router,
        kayak = require( 'kayak/core/kayak' ),
        header = require( 'wuhou/widgets/header/header' ),
        // 其他依赖资源预加载
        kDom = kayak.dom,
        router = kayak.router;

    var p = Page( {
        nodeClass: 'w-p-home',
        parentClass: 'J_Main', // 没有就直接插入body，或者不插入
        source: ['cabin/pages/menu/menu.tpl'],
        show : function() {
            var jView = this.jView;
            //jView.removeClass( 'exit' ).addClass( 'in' );
            header.showMain();
        },
        exitf : function() {
            var jView = this.jView;
            if ( !jView ) {
                return;
            }
            //jView.removeClass( 'in' ).addClass( 'exit' );
            setTimeout( function() {
                jView.kRemove();
            }, 1000 );
        }
    });

    module.exports = p;
} );
