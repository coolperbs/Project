define( 'cabin/layout/monitor', function(  ) {
	return $( {} );
} );